/*
 * PRE_LAB_2.c
 *
 * Created: 13/04/2026 11:35:00
 * Author : Pedro Porras
 */ 

#define F_CPU 1600000
#include <avr/io.h>
#include <util/delay.h>

/****************************************/
// Encabezado (Libraries)

#include "ADC.h"
#include "PWM1.h"
#include "PWM2.h"
void setup();

/****************************************/
// Main Function

int main(void)
{
    setup();
    initPWM1(PWM1A_NO_INVERTIDO, 0 , ICR1_A, ICR1_B, PWM_PR_8, 39999);
	initPWM2(PWM2A_NO_INVERTIDO, 0, PWM2_FAST_MODE, PWM2_PR_1024);
    initADC(ADC_AVCC, ADCH_ACT, PS_8);
    while (1)
    {
        uint8_t pot1, pot2;
        uint16_t pwm_servo1;
		uint8_t pwm_servo2;

        pot1 = readADC(0);
		_delay_ms(10);
        pot2 = readADC(1);
		_delay_ms(10);

        pwm_servo1 =  1000 + (((uint32_t)pot1 * 2000) / 255);
        setPWM1A(pwm_servo1);
        
        pwm_servo2 = 15 + (((uint16_t)pot2 * 16) / 255);
        setPWM2A(pwm_servo2);
		
		_delay_ms(20);
    }
}

/****************************************/
// NON-Interrupt subroutines

void setup(){
	
	DDRC &= ~((1<<DDC0) | (1<<DDC1));
}